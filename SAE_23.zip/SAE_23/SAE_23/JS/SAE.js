// panier.js

// Vérifie si un panier existe dans le localStorage sinon crée-le
let panier = JSON.parse(localStorage.getItem("panier")) || [];

// Ajouter un produit au panier
function ajouterAuPanier(nom, prix) {
    // Vérifie si le produit est déjà dans le panier
    let index = panier.findIndex(p => p.nom === nom);
    if (index !== -1) {
        panier[index].quantite += 1;
    } else {
        panier.push({ nom: nom, prix: prix, quantite: 1 });
    }

    // Sauvegarde dans localStorage
    localStorage.setItem("panier", JSON.stringify(panier));
    alert(nom + " ajouté au panier !");
}

// Supprimer un produit du panier
function supprimerDuPanier(nom) {
    panier = panier.filter(p => p.nom !== nom);
    localStorage.setItem("panier", JSON.stringify(panier));
    afficherPanier(); // Met à jour l’affichage
}

// Afficher le panier sur panier.html
function afficherPanier() {
    let container = document.getElementById("panier-list");
    if (!container) return; // si on est sur une autre page

    container.innerHTML = ""; // vide le conteneur
    let total = 0;

    panier.forEach(p => {
        total += p.prix * p.quantite;

        let div = document.createElement("div");
        div.className = "product";
        div.innerHTML = `
            <h3>${p.nom}</h3>
            <p>Prix : ${p.prix} €</p>
            <p>Quantité : ${p.quantite}</p>
            <button onclick="supprimerDuPanier('${p.nom}')">Supprimer</button>
        `;
        container.appendChild(div);
    });

    document.getElementById("total-panier").innerText = "Total : " + total + " €";
}

// Exécute afficherPanier si on est sur la page panier
window.onload = afficherPanier;