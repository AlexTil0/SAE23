// Récupère le panier ou crée-le vide
let panier = JSON.parse(localStorage.getItem("panier")) || [];

// Ajouter un produit au panier
function ajouterAuPanier(nom, prix) {
    let p = panier.find(x => x.nom === nom);
    if (p) p.quantite++;
    else panier.push({nom: nom, prix: prix, quantite: 1});
    localStorage.setItem("panier", JSON.stringify(panier));
    alert(nom + " ajouté au panier !");
    updateNavbarPanier();
}

// Supprimer un produit du panier
function supprimerDuPanier(nom) {
    panier = panier.filter(x => x.nom !== nom);
    localStorage.setItem("panier", JSON.stringify(panier));
    afficherPanier();
    updateNavbarPanier();
}

// Afficher le panier sur panier.html
function afficherPanier() {
    let c = document.getElementById("panier-list");
    if (!c) return;
    c.innerHTML = "";
    let total = 0;
    panier.forEach(p => {
        total += p.prix * p.quantite;
        c.innerHTML += `
            <div class="product">
                <h3>${p.nom}</h3>
                <p>Prix : ${p.prix} €</p>
                <p>Quantité : ${p.quantite}</p>
                <button onclick="supprimerDuPanier('${p.nom}')">Supprimer</button>
            </div>
        `;
    });
    document.getElementById("total-panier").innerText = "Total : " + total + " €";
}

// Compteur panier dans la navbar
function updateNavbarPanier() {
    let compteur = panier.reduce((acc, p) => acc + p.quantite, 0);
    let lien = document.getElementById("lien-panier");
    if (lien) lien.innerText = `Panier (${compteur})`;
}

// Au chargement de la page
window.onload = function() {
    afficherPanier();
    updateNavbarPanier();
};