// ───────────────────────────────
//  RECHERCHE
// ───────────────────────────────
function rechercherProduit() {
    let input = document.getElementById("searchBar").value.toLowerCase().trim();
    let produits = document.getElementsByClassName("product");

    for (let i = 0; i < produits.length; i++) {
        let texteProduit = produits[i].textContent.toLowerCase();

        if (input === "" || texteProduit.includes(input)) {
            produits[i].style.display = "inline-block";
        } else {
            produits[i].style.display = "none";
        }
    }
}

// ───────────────────────────────
//  PANIER
// ───────────────────────────────

// Récupère le panier depuis localStorage
function getPanier() {
    return JSON.parse(localStorage.getItem("panier")) || [];
}

// Sauvegarde le panier dans localStorage
function savePanier(panier) {
    localStorage.setItem("panier", JSON.stringify(panier));
}

// Ajouter un produit au panier
function ajouterAuPanier(nom, prix) {
    let panier = getPanier();

    // Si le produit existe déjà, on augmente la quantité
    let produitExistant = panier.find(p => p.nom === nom);
    if (produitExistant) {
        produitExistant.quantite += 1;
    } else {
        panier.push({ nom: nom, prix: prix, quantite: 1 });
    }

    savePanier(panier);
    alert(`✅ "${nom}" ajouté au panier !`);
}

// Supprimer un produit du panier
function supprimerDuPanier(nom) {
    let panier = getPanier().filter(p => p.nom !== nom);
    savePanier(panier);
    afficherPanier(); // on rafraîchit l'affichage
}

// Afficher le panier sur Panier.html
function afficherPanier() {
    let panier = getPanier();
    let section = document.getElementById("panier-list");
    let totalEl = document.getElementById("total-panier");

    if (!section) return; // on n'est pas sur la page panier

    section.innerHTML = "";

    if (panier.length === 0) {
        section.innerHTML = "<p>Votre panier est vide.</p>";
        totalEl.textContent = "Total : 0 €";
        return;
    }

    let total = 0;

    panier.forEach(produit => {
        total += produit.prix * produit.quantite;

        let div = document.createElement("div");
        div.classList.add("product");
        div.innerHTML = `
            <h3>${produit.nom}</h3>
            <p>Prix unitaire : ${produit.prix} €</p>
            <p>Quantité : ${produit.quantite}</p>
            <p><strong>Sous-total : ${produit.prix * produit.quantite} €</strong></p>
            <button onclick="supprimerDuPanier('${produit.nom}')">🗑️ Supprimer</button>
        `;
        section.appendChild(div);
    });

    totalEl.textContent = `Total : ${total} €`;
}

// Vider le panier et passer commande
function passerCommande() {
    if (getPanier().length === 0) {
        alert("Votre panier est vide !");
        return;
    }
    localStorage.removeItem("panier");
    alert("✅ Commande passée avec succès ! Merci pour votre achat.");
    afficherPanier();
}

// Lancer l'affichage automatiquement si on est sur la page panier
window.onload = function () {
    afficherPanier();
};