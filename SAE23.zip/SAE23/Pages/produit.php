<?php
// Connexion BDD
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mydb";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connexion échouée : " . $conn->connect_error);
}

// Récupération formulaire
$motcle = isset($_POST['motcle']) ? $_POST['motcle'] : "";
$categorie = isset($_POST['categorie']) ? $_POST['categorie'] : "Tous";

// Requête
$sql = "SELECT * FROM article WHERE 1";

if (!empty($motcle)) {
    $sql .= " AND designation LIKE '%$motcle%'";
}

if ($categorie != "Tous") {
    $sql .= " AND categorie = '$categorie'";
}

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Produits - UPEC-X</title>
    <link rel="stylesheet" href="../styles/SAE23.css">
</head>

<body>

<header>
    <img src="../images/UpecX.png" alt="Logo" class="logo">
    <h1>UPEC-X</h1>
</header>

<nav>
    <ul>
        <li><a href="SAE23.html">Accueil</a></li>
        <li><a href="produit.php">Produits</a></li>
        <li><a href="panier.php">Panier</a></li>
        <li><a href="contact.php">Contact</a></li>
    </ul>
</nav>

<h2 style="text-align:center; margin-top:20px;">Nos Produits</h2>

<!-- 🔎 FORMULAIRE -->
<div class="product-container">
<form method="post" action="produit.php">
    <input type="text" name="motcle" placeholder="Rechercher un produit...">

    <select name="categorie">
        <option value="Tous">Tous</option>
        <option value="PS4">PS4</option>
        <option value="PS5">PS5</option>
        <option value="PC">PC</option>
        <option value="Mobile">Mobile</option>
        <option value="Nintendo Switch">Nintendo Switch</option>
    </select>

    <input type="submit" value="Rechercher">
</form>
</div>

<!-- 📦 PRODUITS -->
<div class="product-container">

<?php
if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
?>

    <div class="product">
        <h3><?php echo $row['designation']; ?></h3>
        <p>Plateforme : <?php echo $row['categorie']; ?></p>
        <p>Prix : <?php echo $row['prix']; ?> €</p>

        <form method="post" action="panier.php">
            <input type="hidden" name="id_article" value="<?php echo $row['id_article']; ?>">
            <input type="hidden" name="designation" value="<?php echo $row['designation']; ?>">
            <input type="hidden" name="prix" value="<?php echo $row['prix']; ?>">

            <input type="number" name="quantite" value="1" min="1">

            <button type="submit">Ajouter au panier</button>
        </form>
    </div>

<?php
    }
} else {
    echo "<p style='text-align:center;'>Aucun produit trouvé</p>";
}
?>

</div>

</body>
</html>

<?php
$conn->close();
?>