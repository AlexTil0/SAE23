<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact - UPEC-X</title>
	<link rel="stylesheet" href="../styles/SAE23.css">
</head>
<body>

<header>
    <img src="../images/UpecX.png" alt="Logo" class="logo">
    <h1>UPEC-X</h1>
</header>

<nav>
    <ul>
        <li><a href="SAE23.html">Accueil</a></li>
        <li><a href="produit.php">Produits</a></li>
        <li><a href="panier.php">Panier</a></li>
        <li><a href="contact.php">Contact</a></li>
    </ul>
</nav>

<h2>Contact</h2>

<!-- Exemple de formulaire de contact -->
<form>
    <input type="text" placeholder="Nom" required><br>
    <input type="email" placeholder="Email" required><br>
    <textarea placeholder="Votre message" rows="5" required></textarea><br>
    <button type="submit">Envoyer</button>
</form>

</body>
</html>