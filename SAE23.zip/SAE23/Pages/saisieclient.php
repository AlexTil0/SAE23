<?php
session_start();

$conn = new mysqli("localhost", "root", "", "mydb");

if ($conn->connect_error) {
    die("Erreur connexion");
}

// 🔐 VERIFICATION CLIENT EXISTANT
if (isset($_POST['verifier'])) {

    $mail = $_POST['mail'];
    $pass = $_POST['pass'];

    $sql = "SELECT * FROM client WHERE mail='$mail'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {

        $client = $result->fetch_assoc();

        if (password_verify($pass, $client['code'])) {

            $_SESSION['id_client'] = $client['id_client'];
            $_SESSION['nom'] = $client['nom'];

            header("Location: paiement.php");
            exit();

        } else {
            echo "❌ Mot de passe incorrect";
        }

    } else {
        echo "❌ Compte introuvable";
    }
}

// 🆕 INSCRIPTION
if (isset($_POST['valider'])) {

    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $age = $_POST['age'];
    $adresse = $_POST['adresse'];
    $ville = $_POST['ville'];
    $mail = $_POST['mail_new'];
    $code = $_POST['code'];

    // vérifier doublon
    $check = $conn->query("SELECT * FROM client WHERE mail='$mail'");

    if ($check->num_rows > 0) {
        echo "⚠️ Compte déjà existant";
    } else {

        $hash = password_hash($code, PASSWORD_DEFAULT);

        $sql = "INSERT INTO client (nom, prenom, age, adresse, ville, mail, code)
                VALUES ('$nom','$prenom','$age','$adresse','$ville','$mail','$hash')";

        if ($conn->query($sql)) {

            $_SESSION['id_client'] = $conn->insert_id;
            $_SESSION['nom'] = $nom;

            header("Location: paiement.php");
            exit();
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Client</title>
	<link rel="stylesheet" href="../styles/SAE23.css">
</head>

<body>

<h2>🔐 Déjà client ?</h2>

<form method="post">
    Email : <input type="email" name="mail" required><br><br>
    Mot de passe : <input type="password" name="pass" required><br><br>
    <button name="verifier">Vérifier</button>
</form>

<hr>

<h2>🆕 Vous n’êtes pas encore client</h2>

<form method="post">

    Nom : <input type="text" name="nom" required><br><br>
    Prénom : <input type="text" name="prenom" required><br><br>
    Âge : <input type="number" name="age" required><br><br>
    Adresse : <input type="text" name="adresse" required><br><br>
    Ville : <input type="text" name="ville" required><br><br>
    Email : <input type="email" name="mail_new" required><br><br>
    Mot de passe : <input type="password" name="code" required><br><br>

    <button name="valider">S'inscrire</button>

</form>

</body>
</html>