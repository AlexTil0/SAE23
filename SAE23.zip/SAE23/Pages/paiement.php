<?php
// Fonction de vérification Luhn
function verifierCarte($numero) {
    $numero = str_replace(' ', '', $numero);

    if (!preg_match('/^[0-9]{16}$/', $numero)) {
        return false;
    }

    $somme = 0;
    $alt = false;

    for ($i = strlen($numero) - 1; $i >= 0; $i--) {
        $n = intval($numero[$i]);

        if ($alt) {
            $n *= 2;
            if ($n > 9) {
                $n -= 9;
            }
        }

        $somme += $n;
        $alt = !$alt;
    }

    return ($somme % 10 == 0);
}

// Traitement du formulaire
$message = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $carte = $_POST["carte"];

    if (verifierCarte($carte)) {
        // Simulation insertion BDD
        $message = "<p style='color:green;'>✅ Paiement validé ! Commande confirmée.</p>";
    } else {
        $message = "<p style='color:red;'>❌ Numéro de carte invalide.</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Paiement</title>
	<link rel="stylesheet" href="../styles/SAE23.css">
</head>
<body>

<!-- En-tête -->
<div class="header">
    <h2>Paiement sécurisé</h2>
</div>

<!-- Bloc de saisie -->
<div class="container">
    <h3>Paiement</h3>

    <form method="POST">
        <label>Carte bancaire :</label><br><br>
        <input type="text" name="carte" maxlength="16" placeholder="16 chiffres" required>
        <br><br>
        <button type="submit">Payer</button>
    </form>

    <br>
    <?php echo $message; ?>
</div>

<!-- Pied de page -->
<div class="footer">
    <a href="#">Continuer la commande</a> |
    <a href="#">Page d'accueil</a>
</div>

</body>
</html>