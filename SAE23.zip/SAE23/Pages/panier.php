<?php
session_start();

// Connexion BDD
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mydb";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connexion échouée : " . $conn->connect_error);
}

// Initialisation panier
if (!isset($_SESSION['panier'])) {
    $_SESSION['panier'] = [];
}

// 🔹 AJOUT
if (isset($_POST['id_article']) && isset($_POST['quantite'])) {
    $id = $_POST['id_article'];
    $quantite = $_POST['quantite'];

    if (isset($_SESSION['panier'][$id])) {
        $_SESSION['panier'][$id] += $quantite;
    } else {
        $_SESSION['panier'][$id] = $quantite;
    }
}

// 🔹 VIDER
if (isset($_POST['vider'])) {
    $_SESSION['panier'] = [];
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Panier - UPEC-X</title>
    <link rel="stylesheet" href="../styles/SAE23.css">
</head>

<body>

<header>
    <img src="../images/UpecX.png" alt="Logo" class="logo">
    <h1>UPEC-X</h1>
</header>

<nav>
    <ul>
        <li><a href="SAE23.html">Accueil</a></li>
        <li><a href="produit.php">Produits</a></li>
        <li><a href="panier.php">Panier</a></li>
        <li><a href="contact.php">Contact</a></li>
    </ul>
</nav>

<h2 style="text-align:center; margin-top:20px;">Mon Panier</h2>

<section style="padding:40px; display:flex; flex-direction:column; align-items:center; gap:20px;">

<?php
if (!empty($_SESSION['panier'])) {

    $total_general = 0;

    foreach ($_SESSION['panier'] as $id => $quantite) {

        $sql = "SELECT * FROM article WHERE id_article = '$id'";
        $result = $conn->query($sql);

        if ($result && $row = $result->fetch_assoc()) {

            $designation = $row['designation'];
            $prix = $row['prix'];
            $total = $prix * $quantite;
            $total_general += $total;
?>

    <div class="product">
        <h3><?php echo $designation; ?></h3>
        <p>Prix : <?php echo $prix; ?> €</p>
        <p>Quantité : <?php echo $quantite; ?></p>
        <p><b>Total : <?php echo number_format($total, 2); ?> €</b></p>
    </div>

<?php
        }
    }
?>

</section>

<div style="text-align:center;">
    <h3>Total : <?php echo number_format($total_general, 2); ?> €</h3>

    <form method="post">
        <button type="submit" name="vider">Vider le panier</button>
    </form>

    <br>

    <a href="produit.php">
        <button>⬅️ Continuer les achats</button>
    </a>

    <br><br>

    <a href="saisieclient.php">
        <button>✅ Commander</button>
    </a>
</div>

<?php
} else {
    echo "<p style='text-align:center;'>Votre panier est vide 🥲</p>";
}
?>

</body>
</html>

<?php
$conn->close();
?>